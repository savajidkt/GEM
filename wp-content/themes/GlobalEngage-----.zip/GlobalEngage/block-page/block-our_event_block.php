<section class="our-event-fild-block">
        <div class="container">
               <h2>Our Events By FIELD</h2>
            <div class="event-item-img-text">
                <div class="img-text">
                    <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/milad-fakurian-58Z17.png"
                        alt="">
                    <a href="#">
                        <h2>Life Science</h2>
                    </a>
                </div>
                <div class="img-text">
                    <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/vadim-gromov-8XFcmzA.png"
                        alt="">
                    <a href="#">
                        <h2>Agricultural Bio-technology</h2>
                    </a>
                </div>
                <div class="img-text">
                    <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/thisisengineering-ra.png"
                        alt="">
                    <a href="#">
                        <h2>Technology</h2>
                    </a>
                </div>
                
            </div>
        </div>

    </section>