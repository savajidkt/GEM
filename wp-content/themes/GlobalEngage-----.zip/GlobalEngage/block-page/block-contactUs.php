<section id="cont-block">
    
    <div class="container">
        <div class="main-count-block">
            <div class="left-cont-data">
                <h2>Contact Us</h2>
                <?php echo do_shortcode('[contact-form-7 id="171" title="Contact Us"]'); ?>
            </div>
            <div class="right-img-cont-data">
                <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/national-cancer-institute-L7en7Lb-Ovc-unsplash.png" alt='img'>
            </div>
            
        </div>
        
    </div>
    
</section>