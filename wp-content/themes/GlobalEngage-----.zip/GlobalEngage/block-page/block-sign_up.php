<section class="sign-up-block">
    <div class="container">
        <div class="form-single-line">
            <h2>sign up & stay informed</h2>
            <?php echo do_shortcode( '[contact-form-7 id="63" title="Contact form 1"]' );?>
        </div>
    </div>
</section>