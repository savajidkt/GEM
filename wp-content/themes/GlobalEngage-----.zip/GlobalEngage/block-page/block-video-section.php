 <section class="video-hal">
        <div class="container">
            <div class="video-wrapper">
                <video src="//cdn.jsdelivr.net/npm/big-buck-bunny-1080p@0.0.6/video.mp4"
                    poster="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/video-poster-e1681552386739.png"></video>
            </div>
            <div class="video-bottom-text">
                <h2>
                    Meet Your Next Big Client, By Sponsoring An Event
                </h2>
                <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut
                    labore et dolore
                    magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
                    Stet clita kasd
                    gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
                <div class="two-btn-video">
                    <button class="btn">Enquire now</button>
                    <a href="#">Read more</a>
                </div>
            </div>
        </div>
    </section>