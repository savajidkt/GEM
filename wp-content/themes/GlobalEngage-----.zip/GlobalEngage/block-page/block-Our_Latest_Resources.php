<section class="our_lr">
        <div class="gallery_title container">
            <div class="gallery_title_content">
                <div>
                    <h3>Our Latest Resources</h3>
                </div>
                <div class="gallery-left-btn-event">
                    <a href="#" class="btn new-btn gal-btn">Blogs1</a>
                    <a href="#" class="new-btn btn-x gal-web">Webinar Recordings</a>
                    <a href="#" class="new-btn btn-x gal-web2">Downloads</a>
                    <a href="#" class="new-btn btn-x gal-web3">View all events</a>
                </div>
            </div>
            
            <div class="gallery-slider">
         
                <div class="text-event-slider">
                  <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/drew-hays-tGYrlchfObE-unsplash-copy.png" alt="">
                  <h2>Blog Title Goes Here On One Or Two Lines…</h2>
                  <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore</p>
                </div>
                
                <div class="text-event-slider">
                  <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/drew-hays-tGYrlchfObE-unsplash-copy.png" alt="">
                  <h2>Blog Title Goes Here On One Or Two Lines…</h2>
                  <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore</p>
                </div>
                
               <div class="text-event-slider">
                  <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/drew-hays-tGYrlchfObE-unsplash-copy.png" alt="">
                  <h2>Blog Title Goes Here On One Or Two Lines…</h2>
                  <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore</p>
                </div>
                
                <div class="text-event-slider">
                  <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/drew-hays-tGYrlchfObE-unsplash-copy.png" alt="">
                  <h2>Blog Title Goes Here On One Or Two Lines…</h2>
                  <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore</p>
                </div>
                
                <div class="text-event-slider">
                  <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/drew-hays-tGYrlchfObE-unsplash-copy.png" alt="">
                  <h2>Blog Title Goes Here On One Or Two Lines…</h2>
                  <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore</p>
                </div>
                
               <div class="text-event-slider">
                  <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/drew-hays-tGYrlchfObE-unsplash-copy.png" alt="">
                  <h2>Blog Title Goes Here On One Or Two Lines…</h2>
                  <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore</p>
                </div>
                
                <div class="text-event-slider">
                  <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/drew-hays-tGYrlchfObE-unsplash-copy.png" alt="">
                  <h2>Blog Title Goes Here On One Or Two Lines…</h2>
                  <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore</p>
                </div>
                
                <div class="text-event-slider">
                  <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/drew-hays-tGYrlchfObE-unsplash-copy.png" alt="">
                  <h2>Blog Title Goes Here On One Or Two Lines…</h2>
                  <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore</p>
                </div>
                
               
              </div>
                  
        </div>
    </section>
    