<section id="usp-section">
        <div class="container">
            
            <div class="usp-section">
                 <div class="usp-items">
                    <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/usp.png" alt="icon"/>
                     <p><span>20+ Years</span>Of Producing Events</p>
                 </div>
                 <div class="usp-items">
                    <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/usp.png" alt="icon"/>
                     <p><span>20+ Years</span>Of Producing Events</p>
                 </div>
                 <div class="usp-items">
                    <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/usp.png" alt="icon"/>
                     <p><span>20+ Years</span>Of Producing Events</p>
                 </div>
                 <div class="usp-items">
                    <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/usp.png" alt="icon"/>
                     <p><span>20+ Years</span>Of Producing Events</p>
                 </div>
            </div>
        </div>
</section>