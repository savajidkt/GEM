jQuery(function ($) {
    jQuery(document).ready(function () {
       
    jQuery(document).on("click", ".clear-filter-reset", function(e){
      e.preventDefault();
      jQuery(".filter-category:checked").each(function() {
            jQuery(this).prop('checked', false);
            
          });
      jQuery('#xclearResourceCentre').addClass('hide');
            var resourceTypeInput = jQuery('.resource-type .sf-option-active').find('input');
            var resourceType ='';
            resourceType = resourceTypeInput[0].value;
            resourceTypeFun(resourceType);
            //jQuery(".resource-type input[value='" + resourceType + "']").trigger('click');
     
    });

    jQuery(document).on("click", ".clear-filter-faq", function(e){
      e.preventDefault();
      jQuery(".filter-category:checked").each(function() {
            jQuery(this).prop('checked', false);
            
            
          });
            jQuery('#xclearFaq').addClass('hide');

            var resourceTypeInput = jQuery('.faq-type .sf-option-active').find('input');
            console.log(resourceTypeInput);
            var resourceType ='';
            resourceType = resourceTypeInput[0].value;
            faqTypeFun(resourceType);
            //jQuery(".faq-type input[value='" + resourceType + "']").trigger('click');
     
    });

    jQuery(document).on("change", "#misha_filters .filter-category", function(e){
          var categoryData =[];

          jQuery(".filter-category:checked").each(function() {
            categoryData.push(jQuery(this).val());
            jQuery('#xclearResourceCentre').removeClass('hide');
          });
          if (categoryData.length === 0) {
              jQuery('#xclearResourceCentre').addClass('hide');
          }
          var resourceTypeInput = jQuery('.resource-type .sf-option-active').find('input');
          console.log(resourceType);
          var resourceType ='';
          resourceType = resourceTypeInput[0].value;
          jQuery('#current_page').val(1);
      var current_page = jQuery('#current_page').val();

          jQuery.ajax({
                   type : "POST",
                   url : frontendajax.ajaxurl,
                   dataType:'html',
                   data : {action: "wp_filter_data",'categoryData':categoryData,'resourceType':resourceType,'page' :current_page},
                   beforeSend : function ( xhr ) {
                    $.blockUI({ message: null });
                  },
                  complete: function() {
                      $.unblockUI();
                  },
                   success: function(response) {
                    var response = jQuery.parseJSON(response);
                        jQuery('#resource-append').html('');
                        jQuery('#resource-remove').css('display','none');                      

                        jQuery('#resource-append').append(response.html);
                        console.log('max'+response.max);
                        console.log((parseInt(current_page) + 1));
                        jQuery('#current_page').val(parseInt(current_page) + 1);
                        if (current_page == response.max || response.max<=0){
                          jQuery('#misha_loadmore').hide();
                        }else{
                          jQuery('#misha_loadmore').show();
                          jQuery('#current_page').val(2);
                        } 

                      }
              });   

          $("#re-compare-bar-tabs div").remove(); 
          $('.re-compare-icon-toggle .re-compare-notice').text(0); 

      });

  // FAQ
   jQuery(document).on("change", "#resource-center-conten_faq .filter-category", function(e){
          var categoryData =[];

          jQuery(".filter-category:checked").each(function() {
            categoryData.push(jQuery(this).val());
            jQuery('#xclearFaq').removeClass('hide');
          });
          if (categoryData.length === 0) {
              jQuery('#xclearFaq').addClass('hide');
          }
          var resourceTypeInput = jQuery('.faq-type .sf-option-active').find('input');
          console.log(resourceType);
          var resourceType ='';
          resourceType = resourceTypeInput[0].value;
          jQuery('#current_page').val(1);
      var current_page = jQuery('#current_page').val();

          jQuery.ajax({
                   type : "POST",
                   url : frontendajax.ajaxurl,
                   dataType:'html',
                   data : {action: "wp_filter_faq_data",'categoryData':categoryData,'faqType':resourceType,'page' :current_page},
                   beforeSend : function ( xhr ) {
                    $.blockUI({ message: null });
                  },
                  complete: function() {
                      $.unblockUI();
                  },
                   success: function(response) {
                    var response = jQuery.parseJSON(response);
                        jQuery('#resource-append').html('');
                        jQuery('#resource-append').append(response.html);
                        console.log('max'+response.max);
                        console.log((parseInt(current_page) + 1));
                        jQuery('#current_page').val(parseInt(current_page) + 1);
                        if (current_page == response.max ){
                          jQuery('#misha_loadmore').hide();
                        }else{
                          jQuery('#misha_loadmore').show();
                          jQuery('#current_page').val(2);
                        } 

                      }
              });   

          $("#re-compare-bar-tabs div").remove(); 
          $('.re-compare-icon-toggle .re-compare-notice').text(0); 

      });

   /*
   * Load More
   */
  $('#misha_loadmore').click(function(){
    
    var categoryData =[];
          jQuery(".filter-category:checked").each(function() {
            categoryData.push(jQuery(this).val());
          });
          var resourceTypeInput = jQuery('.resource-type .sf-option-active').find('input');
          console.log(resourceType);
          var resourceType ='';
          resourceType = resourceTypeInput[0].value;
          var current_page = jQuery('#current_page').val();
          jQuery.ajax({
                   type : "POST",
                   url : frontendajax.ajaxurl,
                   dataType:'html',
                   data : {action: "wp_filter_data",'categoryData':categoryData,'resourceType':resourceType,'page' :current_page},
                   beforeSend : function ( xhr ) {
                    $('#misha_loadmore').text('Loading...'); // some type of preloader
                    $.blockUI({ message: null }); 
                  },
                  complete: function() {
                      $.unblockUI();
                  },
                   success: function(response) {
                    var response = jQuery.parseJSON(response);
                    console.log(response);
                        //jQuery('#resource-append').html('');
                       jQuery('#misha_loadmore').text( 'Load more' );
                        jQuery('#resource-remove').css('display','none');
                        jQuery('#resource-append').append(response.html);
                        
                        jQuery('#current_page').val(parseInt(current_page) + 1);
                        if (current_page == response.max ){
                          jQuery('#misha_loadmore').hide();
                        }else{
                          jQuery('#misha_loadmore').show();
                          jQuery('#current_page').val(parseInt(current_page) + 1);
                        } 
            
                        


                      }
              });

    
  });

   jQuery(document).on("change", ".resource-type .sf-input-radio", function(e){
          var categoryData =[];
          jQuery(".filter-category:checked").each(function() {
            categoryData.push(jQuery(this).val());
          });
          
                var $all_options = jQuery('.top-bar-type-category').find('li');
                    $all_options.removeClass("sf-option-active");

          jQuery(this).parent().addClass('sf-option-active');
          var resourceType = jQuery(this).val();
          jQuery('#current_page').val(1);
          var current_page = jQuery('#current_page').val();
          jQuery.ajax({
                   type : "POST",
                   url : frontendajax.ajaxurl,
                   dataType:'html',
                   data : {action: "wp_filter_data",'categoryData':categoryData,'resourceType':resourceType,'page' :current_page},
                   beforeSend : function ( xhr ) {
                    $.blockUI({ message: null });
                  },
                  complete: function() {
                     $.unblockUI();
                  },
                   success: function(response) {
                    var response = jQuery.parseJSON(response);
                        jQuery('#resource-append').html('');
                        jQuery('#resource-remove').css('display','none');                      

                        jQuery('#resource-append').append(response.html);

                        console.log('max'+response.max);
                        console.log((parseInt(current_page) + 1));
                        jQuery('#current_page').val(parseInt(current_page) + 1);
                        if (current_page > response.max ){
                          jQuery('#misha_loadmore').hide();
                        }else{
                          jQuery('#misha_loadmore').show();
                          jQuery('#current_page').val(2);
                        } 

                      }

              });   

          $("#re-compare-bar-tabs div").remove(); 
          $('.re-compare-icon-toggle .re-compare-notice').text(0); 

      });


   jQuery(document).on("change", ".faq-type .sf-input-radio", function(e){
          var categoryData =[];
          jQuery(".filter-category:checked").each(function() {
            categoryData.push(jQuery(this).val());
          });
          
                var $all_options = jQuery('.top-bar-type-category').find('li');
                    $all_options.removeClass("sf-option-active");

          jQuery(this).parent().addClass('sf-option-active');
          var faqType = jQuery(this).val();
          jQuery('#current_page').val(1);
          jQuery.ajax({
                   type : "POST",
                   url : frontendajax.ajaxurl,
                   dataType:'html',
                   data : {action: "wp_filter_faq_data",'categoryData':categoryData,'faqType':faqType},
                   beforeSend : function ( xhr ) {
                    $.blockUI({ message: null });
                  },
                  complete: function() {
                     $.unblockUI();
                  },
                   success: function(response) {
                    var response = jQuery.parseJSON(response);
                        jQuery('#resource-append').html('');
                        jQuery('#resource-append').append(response.html);

                      }

              });   

          $("#re-compare-bar-tabs div").remove(); 
          $('.re-compare-icon-toggle .re-compare-notice').text(0); 

      });
        
    });
});

function resourceTypeFun(resourceType){
  var categoryData =[];
          jQuery(".filter-category:checked").each(function() {
            categoryData.push(jQuery(this).val());
          });
          
                var $all_options = jQuery('.top-bar-type-category').find('li');
                    $all_options.removeClass("sf-option-active");

          jQuery(".resource-type input[value='" + resourceType + "']").parent().addClass('sf-option-active');
          jQuery('#current_page').val(1);
          var current_page = jQuery('#current_page').val();
          jQuery.ajax({
                   type : "POST",
                   url : frontendajax.ajaxurl,
                   dataType:'html',
                   data : {action: "wp_filter_data",'categoryData':categoryData,'resourceType':resourceType,'page' :current_page},
                   beforeSend : function ( xhr ) {
                    $.blockUI({ message: null });
                  },
                  complete: function() {
                     $.unblockUI();
                  },
                   success: function(response) {
                    var response = jQuery.parseJSON(response);
                        jQuery('#resource-append').html('');
                        jQuery('#resource-remove').css('display','none');                      

                        jQuery('#resource-append').append(response.html);

                        console.log('max'+response.max);
                        console.log((parseInt(current_page) + 1));
                        jQuery('#current_page').val(parseInt(current_page) + 1);
                        if (current_page > response.max ){
                          jQuery('#misha_loadmore').hide();
                        }else{
                          jQuery('#misha_loadmore').show();
                          jQuery('#current_page').val(2);
                        } 

                      }

              });   

          $("#re-compare-bar-tabs div").remove(); 
          $('.re-compare-icon-toggle .re-compare-notice').text(0); 
}

function faqTypeFun(faqType){
      var categoryData =[];
          jQuery(".filter-category:checked").each(function() {
            categoryData.push(jQuery(this).val());
          });
          
                var $all_options = jQuery('.top-bar-type-category').find('li');
                    $all_options.removeClass("sf-option-active");

          jQuery(".faq-type input[value='" + faqType + "']").parent().addClass('sf-option-active');
          jQuery.ajax({
                   type : "POST",
                   url : frontendajax.ajaxurl,
                   dataType:'html',
                   data : {action: "wp_filter_faq_data",'categoryData':categoryData,'faqType':faqType},
                   beforeSend : function ( xhr ) {
                     // $.blockUI({ message: null });
                  },
                  complete: function() {
                     //$.unblockUI();
                  },
                   success: function(response) {
                    var response = jQuery.parseJSON(response);
                        jQuery('#resource-append').html('');
                        jQuery('#resource-append').append(response.html);

                      }

              });   

}
jQuery(function ($) {
    jQuery(document).ready(function () {
      jQuery('.header-slider').slick({
        slidesToShow: 1,
        arrows: false,
        dots: true,
        speed: 300,
        infinite: true,
        autoplaySpeed: 2000,
        autoplay: false,
    });

        jQuery('.event-slider-block').slick({
            slidesToShow: 1,
            arrows: false,
            dots: true,
            speed: 300,
            infinite: true,
            autoplaySpeed: 2000,
            autoplay: false,
        });
    });
});
jQuery(function ($) {
    jQuery(document).ready(function () {
        jQuery('.usp-section').slick({
            arrows: false,
            infinite: true,
            dots: false,
             slidesToShow: 4,
            slidesToScroll: 4,
            speed: 300,
            infinite: true,
            autoplaySpeed: 2000,
            autoplay: false,
            responsive: [
            {
              breakpoint: 1450,
              settings: {
                slidesToShow: 3,
                slidesToScroll: 2,
                infinite: true,
                dots: true
              }
            },
            {
              breakpoint: 1200,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 2
              }
            },
            {
              breakpoint: 600,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1
              }
            },
            {
              breakpoint: 501,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1
              }
            }
            // You can unslick at a given breakpoint now by adding:
            // settings: "unslick"
            // instead of a settings object
          ]
        });
    });
});
// drop down
 jQuery(document).ready(function () {
$(function() {
  var list = $('.js-dropdown-list');
  var link = $('.js-link');
  link.click(function(e) {
    e.preventDefault();
    list.slideToggle(200);
  });
  list.find('li').click(function() {
    var text = $(this).html();
    var icon = '<i class="fa fa-chevron-down"></i>';
    link.html(text+icon);
    list.slideToggle(200);
    if (text === '* Reset') {
      link.html('Select one option'+icon);
    }
  });
});
 });
 
 
 
 
// // video section
// const videoPlayer = document.querySelector('.video-player')
// const videoss = videoPlayer.querySelector('.video')
// const playButton = videoss.querySelector('.play-button')
// // Play and Pause
// playButton.addEventListener('click', (e) => {
//     if(video.paused){
//         video.play()
//         e.target.textContent = '❚ ❚'
//     } else {
//         video.pause()
//         e.target.textContent = '►'
//     }
// })
// end video js
// header sticky JS Code
// end JS code
jQuery(function ($) {
    jQuery(document).ready(function () {
       $('.image-slider').slick({
                arrows: false,
                dots: true,
                infinite: true,
                speed: 500,
              //   slidesToShow: 1,
                slidesToShow: 4,
                centerMode: true,
              //   variableWidth: true,
                draggable: true,
                 responsive: [
                  {
                    breakpoint: 1024,
                    settings: {
                      slidesToShow: 3,
                      slidesToScroll: 3,
                      infinite: true,
                      dots: true
                    }
                  },
                  {
                    breakpoint: 600,
                    settings: {
                      slidesToShow: 2,
                      slidesToScroll: 2
                    }
                  },
                  {
                    breakpoint: 480,
                    settings: {
                      slidesToShow: 1,
                      slidesToScroll: 1
                    }
                  }
                  
                ]
              });

       
       $(document).on('click','#BlogsBtn',function(){
        
        $('#WebinarBtn').removeClass('active');
        $('#DownloadsBtn').removeClass('active');
        $('#BlogsBtn').addClass('active');
            destroyCarousel();
            slickCarousel();
       });
       $(document).on('click','#WebinarBtn',function(){
        $('#BlogsBtn').removeClass('active');
        $('#DownloadsBtn').removeClass('active');
        $('#WebinarBtn').addClass('active');
            destroyCarousel();
            slickCarousel();
       });
       $(document).on('click','#DownloadsBtn',function(){
        $('#WebinarBtn').removeClass('active');
        $('#BlogsBtn').removeClass('active');
        $('#DownloadsBtn').addClass('active');
            destroyCarousel();
            slickCarousel();
       });




    


    });

    
    function slickCarousel() {
    $('.gallery-slider').slick({               
                dots: true,
                infinite: true,
                speed: 300,             
                slidesToShow: 4,
                slidesToScroll: 4,               
                 responsive: [
                  {
                    breakpoint: 1200,
                    settings: {
                      slidesToShow: 3,
                      slidesToScroll: 3,
                      infinite: true,
                      dots: true
                    }
                  },
                  {
                    breakpoint: 600,
                    settings: {
                      slidesToShow: 2,
                      slidesToScroll: 2
                    }
                  },
                  {
                    breakpoint: 480,
                    settings: {
                      slidesToShow: 1,
                      slidesToScroll: 1
                    }
                  }
                  
                ]
              });
  }
  function destroyCarousel() {
    if ($('.gallery-slider').hasClass('slick-initialized')) {
      $('.gallery-slider').slick('destroy');
    }      
  }

    $(window).on('load', function() {
      // BLog slider
       $('.gallery-slider').slick({
        dots: true,
        infinite: true,
        speed: 300,             
        slidesToShow: 4,
        slidesToScroll: 4,   
                 responsive: [
                  {
                    breakpoint: 1200,
                    settings: {
                      slidesToShow: 3,
                      slidesToScroll: 3,
                      infinite: true,
                      dots: true
                    }
                  },
                  {
                    breakpoint: 700,
                    settings: {
                      slidesToShow: 2,
                      slidesToScroll: 2
                    }
                  },
                  {
                    breakpoint: 480,
                    settings: {
                      slidesToShow: 1,
                      slidesToScroll: 1
                    }
                  }
                  
                ]
              });


                setTimeout(function () {
                  console.log('click');
                     $('#BlogsBtn').trigger('click');
                 }, 2000);


  });

});
// popup forms for webinar recording
function showDiv_sign() {
   document.getElementById('login_popup').style.display = "block";
}
// function closeDiv_sign() {
//   document.getElementById('login_popup').style.display = "none";
// }


window.onload = function() {
  var popupForm = document.getElementById('popupForm');
  //var closeButton = document.getElementById('closeButton');

  popupForm.style.display = 'block';

//   closeButton.onclick = function() {
//     popupForm.style.display = 'none';
//   };
if (typeof slickCarousel == 'function') { 

  slickCarousel();
}
};


// popup for sponsor widget

function sponPopup(popupId) {
  $('.'+popupId).show();
  //document.getElementsByClassName(popupId).style.display = "block";
 
}
function sponPopupClose(popupId) {
  
  $('.'+popupId).hide();
}

document.addEventListener('DOMContentLoaded', function() {

// Add active class to the current button (highlight it)
var header = document.getElementById("mBtnWeb");
if(header){
var btns = header.getElementsByClassName("mBtnWeb");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function() {
  var current = document.getElementsByClassName("btnactive");
  current[0].className = current[0].className.replace("btnactive", "");
  this.className += " active";
  });
}
}
}, false);