<?php
/* Template Name: 404 Template*/ 
get_header(); ?>
<section>
    <div class="error-page">
        
        <div class="error_text">
        
            <h2 style="text-align:center;">404 Page Not Found</h2>

        </div>
                   
    </div>
</section>

<?php get_footer();