<section class="our-event-fild-block">
        <div class="container">
               <h2>Our events by continent</h2>
            <div class="event-item-img-text">
                <div class="img-text">
                    <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/nik-shuliahin-L4JWn8.png"
                        alt="">
                    <a href="#">
                        <h2>USA</h2>
                    </a>
                </div>
                <div class="img-text">
                    <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/jj-ying-9Qwbfa_RM94-.png"
                        alt="">
                    <a href="#">
                        <h2>Asia</h2>
                    </a>
                </div>
                <div class="img-text">
                    <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/massimiliano-morosin.png"
                        alt="">
                    <a href="#">
                        <h2>Europe</h2>
                    </a>
                </div>
            </div>
        </div>

    </section>