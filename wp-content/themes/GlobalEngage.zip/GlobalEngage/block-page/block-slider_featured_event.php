<section class="featured_event_slider">
    <div class=" container">
    <div class="featured_event_slider_content">
        <div class="featured_event_slider_image">
            <div class="event-slider-block">
                <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/fusion-medical-animation-EAgGqOiDDMg-unsplash.png" alt="fusion" />
                <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/fusion-medical-animation-EAgGqOiDDMg-unsplash.png" alt="fusion" />
                <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/04/fusion-medical-animation-EAgGqOiDDMg-unsplash.png" alt="fusion" />
            </div>
        </div>
        <div class="featured_event_slider_text">
            <h3>Featured Event Title goes here or on two lines</h3>
            <p class="event-sub-text">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                tempor invidunt ut labore et dolore magna aliquyam</p>
            <div class="featured_event_slider_button">
                <button class="btn">Find out more</button>
                <a hreft="#"><p class="view_events">View all events</p></a>
            </div>
        </div>
    </div>
    </div>
</section>