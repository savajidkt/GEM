<?php if(!empty($section_data)): 
    $reviews=$section_data['reviews'];
   ?>
<section>
          <div class="container">
              <div class="main_review_section">
               <div class="review_left_text">
                   <?php if(!empty($reviews)) { ?>
                        <h2><?php echo $reviews;?></h2>
                         <?php } ?>
                        <div class="star_icon">
                            <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                            <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                            <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                            <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                            <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                        </div>
                        <h3>Based On 226 reviess</h3>
                        <div class="icon_text_left">
                            <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                            <h3>trustpilot</h3>
                        </div>
               </div>
                       <div class="review_right_side">
                                <div class="review_slider">
                                    <div class="img_right_review">
                                        <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                                          <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                                            <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                                              <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                                                <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                                    </div>
                                    <div class="right_review_text">
                                        <h2>Lorem ipsum </h2>
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur a minima facere accusantium. Neque, vel.</p>
                                        <span>
                                            Lorem ipsum dolor sit.
                                        </span>
                                    </div>
                             </div>
                             
                             <div class="review_slider">
                                    <div class="img_right_review">
                                        <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                                          <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                                            <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                                              <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                                                <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                                    </div>
                                    <div class="right_review_text">
                                        <h2>Lorem ipsum </h2>
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur a minima facere accusantium. Neque, vel.</p>
                                        <span>
                                            Lorem ipsum dolor sit.
                                        </span>
                                    </div>
                             </div>
                              <div class="review_slider">
                                    <div class="img_right_review">
                                        <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                                          <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                                            <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                                              <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                                                <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                                    </div>
                                    <div class="right_review_text">
                                        <h2>Lorem ipsum </h2>
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur a minima facere accusantium. Neque, vel.</p>
                                        <span>
                                            Lorem ipsum dolor sit.
                                        </span>
                                    </div>
                             </div>
                              <div class="review_slider">
                                    <div class="img_right_review">
                                        <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                                          <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                                            <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                                              <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                                                <img src="https://gemain.cda-development3.co.uk/wp-content/uploads/2023/05/star.png" alt="icon">
                                    </div>
                                    <div class="right_review_text">
                                        <h2>Lorem ipsum </h2>
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur a minima facere accusantium. Neque, vel.</p>
                                        <span>
                                            Lorem ipsum dolor sit.
                                        </span>
                                    </div>
                             </div>
                       </div>
               </div>
          </div>
    </section>
<?php endif;?>